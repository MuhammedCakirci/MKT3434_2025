# ML GUI Assignment 

This application is an interactive PyQt-based graphical interface for experimenting with machine learning algorithms, data preprocessing strategies, and visualization tools. It has been enhanced with additional functionalities including support for SVR, missing value handling, custom priors for Naive Bayes, and more.

---

##  Features Overview

###  Classical Machine Learning
- Linear Regression
- Logistic Regression
- Naive Bayes (GaussianNB with optional custom priors)
- Support Vector Machine (SVM with kernel/epsilon/C options)
- Decision Tree, Random Forest
- K-Nearest Neighbors

###  Dimensionality Reduction
- PCA (Principal Component Analysis)
- K-Means Clustering

###  Deep Learning
- MLP builder with dynamic layer architecture (Dense, Dropout, etc.)
- Training parameter control (batch size, epochs, learning rate)
- CNN & RNN sections (structure only, marked for future work)

###  Reinforcement Learning
- Dropdown to simulate RL environments (no back-end simulation integrated)

---

## New Enhancements (2025)

###  Missing Data Strategy
Added dropdown to choose how to handle missing values:
- None
- Mean Imputation
- Interpolation
- Forward Fill / Backward Fill

Implemented using `SimpleImputer`, `pandas.interpolate()`, and related methods.

###  SVR Support
- Implemented SVR under classical ML
- Parameters: `C`, `epsilon`, `kernel` type

###  Naive Bayes with Custom Priors
- Allows the user to input comma-separated priors (e.g., `0.3, 0.7`) for use in GaussianNB.

###  Loss Function Selection
- For Regression: MSE, MAE, Huber Loss
- For Classification: Cross-Entropy, Hinge Loss

###  Enhanced Visualization
- PCA-based 2D plots for classification
- Regression scatter plot of actual vs predicted


##  Author Notes
This project was extended as part of the 2025 MKT3434 Machine Learning assignment.

